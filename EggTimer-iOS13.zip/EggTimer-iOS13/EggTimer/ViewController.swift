//libraries used UIkit
//  ViewController.swift
//  EggTimer
// What? no.
//  Created by Teimur on 08/07/2023.
//  Copyright © 2023 The RR consulting Teimur. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {
    @IBOutlet weak var titleLabel: UILabel!
       
    @IBOutlet weak var timeBar: UIProgressView!
    
    
    let eggsTimes = ["Soft": 5, "Medium": 10, "Hard": 720]
    var countdownTimer: Timer?
    var totalTime = 0
    var secondsPassed = 0
    var audioPlayer: AVAudioPlayer?
    
    
    @IBAction func hardnessSelected(_ sender: UIButton) {
        timeBar.progress = 1.0
        
        let hardness = sender.currentTitle!
        totalTime = eggsTimes[hardness]!
        
        timeBar.progress = 0.0
        secondsPassed = 0
        titleLabel.text = hardness
        startCountdown()
    }
    
    func startCountdown() {
        countdownTimer?.invalidate() // Invalidate any existing timer
        
        countdownTimer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { [weak self] timer in
            guard let self = self else { return }
            
            if secondsPassed < totalTime {
                secondsPassed += 1
                timeBar.progress = Float(secondsPassed) / Float(totalTime)
               
              
            } else {
                timer.invalidate()
                titleLabel.text = "Done!"// Stop the timer when countdown reaches 0
                self.playAlarmSound()
            }
        }
    }
    func playAlarmSound() {
           guard let soundURL = Bundle.main.url(forResource: "alarm_sound", withExtension: "mp3") else {
               return
           }
           
           do {
               audioPlayer = try AVAudioPlayer(contentsOf: soundURL)
               audioPlayer?.play()
           } catch {
               print("Error playing sound: \(error)")
           }
       }
    
}
